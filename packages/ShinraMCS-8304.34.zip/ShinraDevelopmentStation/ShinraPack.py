#!/usr/bin/env python3

import hashlib
import os
import re
import json
import argparse
import logging
import zipfile
import shutil
import sys

logger = logging.getLogger(__name__)

CONF_FILE_NAME = 'Configuration.json'
MANIFEST_FILE_NAME = 'Manifest.txt'

# TODO: handle links
def getFileHash(fileName, blockSizeBytes = 1024 * 1024 * 4):
	h = hashlib.sha1()
	with open(fileName, 'rb') as f:
		while True:
			#logger.debug("Hash progress {0}%".format(progression))
			tmp = f.read(blockSizeBytes)
			if not tmp:
				break
			h.update(tmp)
	return h.hexdigest()

def getZipFileHash(zip, fileName, blockSizeBytes = 1024 * 1024 * 4):
	h = hashlib.sha1()
	with zip.open(fileName, 'r') as f:
		while True:
			#logger.debug("Hash progress {0}%".format(progression))
			tmp = f.read(blockSizeBytes)
			if not tmp:
				break
			h.update(tmp)
	return h.hexdigest()

def getStringHash(data):
	h = hashlib.sha1()
	h.update(data)
	return h.hexdigest()

def loadManifest(manifestPath):
	result = {}
	with open(manifestPath, 'r') as f:
		fileMatchProg = re.compile('(.+)[\s]+([0-9a-f]{40})$')
		for line in f:
			line = line.strip()
			if line.startswith('//') or line.startswith('#'):
				continue
			m = fileMatchProg.match(line)
			if m:
				result[m.group(1)] = m.group(2)
	return result

def saveManifest(manifest, filePath):
	with open(filePath, 'w') as f:
		for k, v in manifest.items():
			f.write("{0} {1}\n".format(k, v))

def jsonLoad(filePath):
	with open(filePath, "r") as f:
		return json.load(f) 

def jsonSave(obj, filePath):
	with open(filePath, "w") as f:
		json.dump(obj, f, sort_keys=True, indent=4)

def isIgnoreFile(filePath):
	if filePath.endswith(".log"):
		return True
	if filePath.endswith(".mdmp"):
		return True
	if os.path.islink(filePath):
		return True
	return False

def getTotalFilesSizes(dataDir):
	max = 0
	for root, dirs, files in os.walk(dataDir):
		for f in files:
			fullPath = os.path.join(root, f)
			if isIgnoreFile(fullPath):
				continue
			max += os.path.getsize(fullPath)
	return max

def getTotalFilesSizesFromArchive(zipPath):
	max = 0
	with zipfile.ZipFile(zipPath, "r") as z:
		for zinfo in z.infolist():
			max += zinfo.file_size;
	return max

def getDataPackFromId(project, id):
	for d in project['dataPacks']:
		if d['id'] == id:
			return d
	return None

def getFilesFromDataPack(datapack):
	all_files = {}
	for map in datapack['files']:
		mapFsysPath = map['fileSystemPath']
		mapAliasPath = map['aliasPath']
		if os.path.isdir(mapFsysPath):
			for root, dirs, files in os.walk(mapFsysPath):
				for f in files:
					filePath = os.path.join(root, f)
					aliasPath = os.path.relpath(filePath, mapFsysPath)
					aliasPath = os.path.join(mapAliasPath, aliasPath)
					all_files[aliasPath] = filePath
		elif os.path.isfile(mapFsysPath):
			filePath = mapFsysPath
			aliasPath = os.path.relpath(filePath, mapFsysPath)
			aliasPath = os.path.join(mapAliasPath, aliasPath)
			all_files[aliasPath] = filePath
		else:
			raise RuntimeError("File mapping in data pack {0} refers to invalid path: {1}", datapack['id'], map['fileSystemPath'])
	return all_files

def zipHashJson(z, obj, path):
	s = json.dumps(obj, sort_keys=True, indent=4).encode('utf-8')
	z.writestr(path, s)
	return getStringHash(s)

def zipManiefst(z, manifest):
	s = ""
	for path, hash in manifest.items():
		# ensure Unix style directory separator. Python on Windows can work with "/"
		path = path.replace("\\", "/")
		s += "{0} {1}\n".format(hash, path)
	z.writestr(MANIFEST_FILE_NAME, s)

def isChildPath(parent, child):
	parentPath = re.split("[\\/]", parent)
	childPath = re.split("[\\/]", child)
	if len(parentPath) > len(childPath):
		return False
	while len(parentPath) > 0:
		if (parentPath[0] != childPath[0]):
			return False
		parentPath.pop(0)
		childPath.pop(0)
	return True

class ShinraPack:
	"""Manages a ShinraPackage"""
	
	def __init__(self, archive):
		self.archive = archive
	
	def compress(self, projectFile):
		proj = jsonLoad(projectFile)
		datapacks = {}
		conf = { 'id': proj['projectName'], 'version': proj['projectVersion'] , 'startups' : [], 'server_packs' : [] }
		for c in proj['startups']:
			p = getDataPackFromId(proj, c['dataPackId'])
			if p == None:
				raise RuntimeError("Startup configuration {0} refer to non existing data pack {1}.".format(c['id'], c['dataPackId']))
			datapacks[p['id']] = p
			conf['startups'].append(c)
		for dpid, datapack in datapacks.items():
			conf['server_packs'].append(dpid)
		manifest = {}
		with zipfile.ZipFile(self.archive, 'w', allowZip64=True) as z:
			manifest[CONF_FILE_NAME] = zipHashJson(z, conf, CONF_FILE_NAME)
			for dpid, datapack in datapacks.items():
				srvConf = { 'id': datapack['id'], 'version': datapack['version'] }
				srvConfFile = os.path.join(datapack['id'], CONF_FILE_NAME)
				manifest[srvConfFile] = zipHashJson(z, srvConf, srvConfFile)
				for alias, file in getFilesFromDataPack(datapack).items():
					alias = os.path.join(datapack['id'], alias)
					manifest[alias] = getFileHash(file)
					z.write(file, alias)
			zipManiefst(z, manifest)
	
	def isValid(self):
		"""Check if the package is valid. Perform a manifest validation."""
		if not os.path.exists(self.configPath):
			logger.error("Configuration file %s not found", self.configPath)
			return False
		if not os.path.exists(self.manifestPath):
			logger.error("No manifest file %s file found", self.manifestPath)
			return False
		conf = self.loadPackConfig()
		if not 'server_packs' in conf:
			logger.error("Not server packs found in configuration")
			return False
		for srvId in conf['server_packs']:
			srvConfPath = os.path.join(self.rootDir, srvId, CONF_FILE_NAME)
			if not os.path.exists(srvConfPath):
				logger.error("Not configuration found for server {0}: {1}", srvId, srvConfPath)
				return False
		m = loadManifest(self.manifestPath)
		if not self.validateManifest(m, self.rootDir):
			logger.error("Manifest is not valid")
			return False
		return True
	
	def progressInit(self, totalSize):
		self.increment = totalSize//100
		self.percent = 0
		self.current = 0

	def progressUpdate(self, filesize):
		if self.increment:
			self.current += filesize;
			if self.current > self.increment:
				self.percent += self.current // self.increment
				self.current = self.current % self.increment
				logger.info("Progression: %d%%", self.percent)
	
	def validate(self):
		isValid = True
		manifestline = re.compile("([0-9a-fA-F]+)\s+(.*)")
		with zipfile.ZipFile(self.archive, 'r', allowZip64=True) as z:
			manifest = {}
			with z.open(MANIFEST_FILE_NAME) as mdata:
				for l in mdata:
					l = l.decode("utf-8")
					match = manifestline.match(l)
					if match:
						hash = match.group(1)
						fileName = match.group(2)
						manifest[fileName] = hash
					else:
						logger.error('failed to parse manifest line: %s', l)
			for file, hash in manifest.items():
				h = getZipFileHash(z, file)
				if h != hash:
					logger.error("Non matching hash for %s. Expected %s got %s", file, hash, h)
					isValid = False
				else:
					logger.debug("Hash OK for %s. Expected %s got %s", file, hash, h)
		return isValid
	
	def uncompress(self, path):
		with zipfile.ZipFile(self.archive, "r") as z:
			with z.open(CONF_FILE_NAME) as confData:
				confData = confData.read().decode("utf-8")
				conf = json.loads(confData)
			for srvPackId in conf['server_packs']:
				srvPackPath = os.path.join(path, srvPackId)
				for finfo in z.infolist():
					if (isChildPath(srvPackId, finfo.filename)):
						logger.debug("Extract %s to %s", finfo.filename, path)
						z.extract(finfo, path)
	
	def createproject(self, project, path):
		with zipfile.ZipFile(self.archive, "r") as z:
			with z.open(CONF_FILE_NAME) as confData:
				confData = confData.read().decode("utf-8")
				conf = json.loads(confData)
			proj = { 'projectName': conf['id'], 'projectVersion': conf['version'],
					 'startups': [], 'dataPacks': []
					}
			for srvPackId in conf['server_packs']:
				srvPackPath = os.path.join(path, srvPackId)
				srvPackconfPath = srvPackId + "/" + CONF_FILE_NAME
				with z.open(srvPackconfPath) as confData:
					srvPackData = confData.read().decode("utf-8")
					srvPackConf = json.loads(srvPackData)
				datapack = { 'id': srvPackConf['id'],
							 'version': srvPackConf['version'],
							 'files': [
								{ 'aliasPath': '',
								  'fileSystemPath': srvPackPath
								}
							]}
				proj['dataPacks'].append(datapack)
			for startupcfg in conf['startups']:
				proj['startups'].append(startupcfg)
			with open(project, 'w') as f:
				json.dump(proj, f, sort_keys=True, indent=4)
	
	def getConf(self):
		with zipfile.ZipFile(self.archive, "r") as z:
			with z.open(CONF_FILE_NAME) as confData:
				confData = confData.read().decode("utf-8")
				return json.loads(confData)
	
	def getServerConf(self, serverId):
		with zipfile.ZipFile(self.archive, "r") as z:
			srvPackconfPath = serverId + "/" +  CONF_FILE_NAME
			with z.open(srvPackconfPath) as confData:
				srvPackData = confData.read().decode("utf-8")
				return json.loads(srvPackData)

if __name__ == "__main__":
	rootlog = logging.getLogger()
	rootlog.setLevel(logging.DEBUG)
	ch = logging.StreamHandler(sys.stdout)
	rootlog.addHandler(ch)
	ch.setLevel(logging.DEBUG)
	
	parser = argparse.ArgumentParser(description='Shinra pack creation manager')
	parser.add_argument('--shinrapack', metavar='archive', help='Archive file to use as Shinra pack.', required=True)
	parser.add_argument('--from-project', metavar='project', help='Create a shinra pack archive from a shinra projefct file.')
	parser.add_argument('--install-to', metavar='path', help='Extract a shinra pack data to specified path.')
	parser.add_argument('--make-project', nargs=2, metavar=('project', 'path'), help='Make a project file with data path prionting to given path.')
	parser.add_argument('--get-conf', action='store_true', help='Output the shinra pack configuration on standard output.')
	parser.add_argument('--get-server-conf', metavar='server-id', help='Output the server pack configuration for server-id on standard output.')
	parser.add_argument('--validate', action='store_true', help='Check files in the archive are valid against the manifest file.')
	parser.add_argument('--log', help='Set the verbosity level for the logs')
	
	args = parser.parse_args()
	
	pack = ShinraPack(args.shinrapack)
	
	if args.from_project:
		pack.compress(args.from_project)
	
	if args.validate:
		if not pack.validate():
			sys.exit(1)
	
	if args.install_to:
		pack.uncompress(args.install_to)
	
	if args.make_project:
		pack.createproject(args.make_project[0], args.make_project[1])
	
	if args.get_conf:
		conf = pack.getConf()
		print(conf)
	
	if args.get_server_conf:
		conf = pack.getServerConf(args.get_server_conf)
		print(conf)
	