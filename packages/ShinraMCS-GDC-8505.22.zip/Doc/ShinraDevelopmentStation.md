ShinraDevelopmentStation
========================

The ShinraDevelopmentStation (SDS) is in charge of managing Shinra game projects. Its main purpose is to create and modify project files.
Those project files can then be used to locally run games using MCS, or create
Shinra packages for Cloud deployment.

Interface overview
------------------

The interface is composed of three main elements:
- **The menu bar** on the top gives access to most of the important actions like project loading and saving, or configuration settings of SDS itself.
- **The project tree** on the left gives a representation of the different elements of the project including the data packs and the startup configurations. Those two concepts are detailed in the Shinra Project Structure section below. You can select individual element in the tree to have access to its properties and edit them.
- **The contextual properties** on the right will display a set of properties you can edit. Those properties will vary depending on the selected item in the project tree.

Shinra Project structure
------------------------

A Shinra project is composed of two main parts: the **data packs** and the **startup configurations**.
A data pack allows to define a directory containing the data that will be included in the game deployment.
A statup configuration allows to define the executable and parameters required to start a game.
All the paths specified in a startup configuration are relative to a data pack, so your need to specify which data pack to use for each startup configuration.
The normal flow of configuration is to first create a data pack, and then to crate a startup configuration using an executable contained in this data pack.


### Create a data pack

You can create a new Data pack by three different means:
- Click "Add data pack" in the Project menu.
- Right click on the "Data packs" section in the project tree and select "Add data pack".
- Drag and drop a directory containing the data on the project tree.

Once you have your Data pack created, you can configure the different properties:
- **Id** is string used to identify this data pack from the others. It can be configured to your liking.
- **Version** is a string used only for tracking purpose.
- **Directory** is the path where the data you want to include is located.
- **Alias** is the name of the directory under which the data will be deployed. By default it is the same as the original directory name, but it can be changed for convenience.


### Create a startup configuration

You can create a new Startup configuration by three different means:
- Click "Add Startup configuration" in the Project menu.
- Right click on the "Startup configurations" section in the project tree and select "Add Startup configuration".
- For a given Data pack, right click on an executable file you want to start and select "Add startup configuration".

Once you have your Startup configuration created, you can configure the different properties:
- **Id** is a string used to identify this startup configuration form the others.
- **Executable** is the path to the executable inside the data pack.
- **Arguments** will be used when running the executable.
- **Work directory** will be used as the current work directory for the execution. The path is relative to Data pack itself.
- **Data pack** will be used as the reference for path definition.

Note you can drag the files from the data pack preview window to the text fields.
You can also have multiple startup configurations pointing at the same executable in the same data pack and using different arguments.

MCS Game deployment
-------------------

Projects can be deployed locally and executed using MCS.

### MCS configuration

You can check the MCS configuration by clicking  "MCS Configuration" in the Project menu.

**MCS Directory** must be set to the directory where the MCS package was unzipped. This directory contains the various executables and Dlls required to run a game in MCS environment. SDS will automatically create links and configuration files to run the game for you.

**Games execution dir** will be used as a root directory to deploy the game files locally and perform execution. Make sure it points to a directory where you have proper write access, and enough disk space to receive the files from the data packs.

### Start a game

You can start a game using MCS in two different ways:
- In the Project menu select "Start game", then select the startup configuration you want to run.
- Right click on a given Startup configuration and select "Start game".

When starting a game, the game data will be deployed in the directory specified under the "MCS configuration", and then executed there.

ShinraPack packaging
--------------------

Projects can be packaged in a ShinraPack archive for deployment on the Cloud servers. For this you need check the ShinraPack configuration.

### ShinraPack configuration

You can check the ShinraPack configuration by clicking "ShinraPack Configuration" in the Project menu.

**Python executable** is the path to python.exe used to execute the packaging script. Python 3 is required.

**ShinraPack script** is the path to the shinra.py script used for packaging.


### Create a ShinraPack

You can create a ShinraPack in two different ways:
- In the Project menu select "Build ShinraPack".
- Right click on the project item in the project tree and select "Start game".

Shinra project file format
--------------------------

The Shinra project information is stored in a json file with .shinra extension. Here is a sample project with just one data pack and one startup configuration.

```
{
  "projectName": "SSW",
  "projectVersion": "001",
  "startups": [
    {
      "id": "sswin",
      "dataPackId": "SSW",
      "executable": "v0.9.33\\sswin.exe",
      "workDir": "v0.9.33",
      "arguments": "--debug"
    }
  ],
  "dataPacks": [
    {
      "id": "SSW",
      "version": "001",
      "files": [
        {
          "aliasPath": "v0.9.33",
          "fileSystemPath": "D:\\Games\\SpaceSweeperClient_v0.9.33\\v0.9.33"
        }
      ]
    }
  ]
}
```

Shinra script
-----------------

The shinra.py script is used as a back-end by SDS to handle packaging, game installation and execution. It can be used as a stand alone tool to automate ShinraPack generation and some deployment tasks.

```
usage: shinra.py [-h] [--mcs-install MCS_INSTALL]
                 [--log-level {DEBUG,INFO,WARN,ERROR}] [--log-file LOG_FILE]
                 {package,install,project,run} ...

Shinra MCS management script.

positional arguments:
  {package,install,project,run}
                        command help.
    package             Create a Shinra package from a project.
    install             Install a game from a project.
    project             Build a project from a package.
    run                 Run an installed game.

optional arguments:
  -h, --help            show this help message and exit
  --mcs-install MCS_INSTALL
                        Directory where MCS is installed. By default it is
                        assumed shinra.py is placed in the python directory
                        under the MCS installation path.
  --log-level {DEBUG,INFO,WARN,ERROR}
  --log-file LOG_FILE
```


### Package command

```
usage: shinra.py package [-h] project archive

positional arguments:
  project     Shinra project to use.
  archive     Shinra package to create.

optional arguments:
  -h, --help  show this help message and exit
```
The following example produces the package "package.zip" from the project file "project.shinra":
```
shinra.py package project.shinra archive.zip
```

### Install command

```
usage: shinra.py install [-h] [-nbinst NBINST] [-overwrite]
                         project startup dir

positional arguments:
  project         Shinra project to install.
  startup         Id of the startup configuration to install.
  dir             Installation directory.

optional arguments:
  -h, --help      show this help message and exit
  -nbinst NBINST  Number of game instances to allow. Default is one.
  -overwrite      Force overwrite of files on install. By default, only files
                  with a older modification date than the source are
                  overwritten on install.
```

The following example installs the SSW startup configuration from the project "project.shinra" in the "C:\Flare\Games\SSW" directory:
```
shinra.py install project.shinra SSW C:\Flare\Games\SSW
```

### Run command
```
usage: shinra.py run [-h] dir userid gameid gameport videoport

positional arguments:
  dir         Path to the game installation.
  userid      User id to use to run the game.
  gameid      Startup id to use to run the game.
  gameport    Port to use for game communications.
  videoport   Port to use for video communications.

optional arguments:
  -h, --help  show this help message and exit
```
The following example starts a game instance for the SSW startup configuration, using the user "user47", game port 60000 and video port 60001.
```
shinra.py run C:\Flare\Games\SSW user47 SSW 60000 60001
```
Note the client has to be executed with a matching port configuration to be able to connect.

### Project command

```
usage: shinra.py project [-h] archive dir project

positional arguments:
  archive     Shinra package to use as source.
  dir         Directory where to store project data.
  project     Name of Shinra project file to create.

optional arguments:
  -h, --help  show this help message and exit
```

The following example will extract the package data in "C:\Path\to\data", and create a new project file with the proper datapack configuration pointing to the extracted data, and the corresponding startup configurations.
```
shinra.py project archive.zip C:\Path\to\data project.shinra
```
