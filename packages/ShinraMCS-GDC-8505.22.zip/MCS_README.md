# Shinra MCS

Shinra MCS is a minimal emulator of Shinra Remote Renderer.

## How to install

1. Unpack the ShinraMCS.zip file next to your game executable.  There should be two batch files, a CloudProperties.json file and a Shinra directory including the Shinra MCS libraries for both x86 and x64 architectures.
2. Modify the LinkShinraDLL.bat to specify either x86 or x64 architecture depending on your game architecture.
3. Run LinkShinraDLL.bat.  It will link or copy the Shinra MCS libraries next to your executable.
4. Run StartShinraClient.bat.  It will start a new client, ready for your game to run.
5. Start your game and press 'Enter' in the Shinra Client.  It will connect to your game and allow you to play.

## How to play remotely

Just unpack the library in the remote computer, then edit the StartShinraClient.bat to point to the IP address where you run the game.  You can then start the Shinra Client and connect to your game.

## <a name="CloudProperties"></a>CloudProperties options

The CloudProperties.json contains a default configuration to allow the game to run smoothly in Shinra MCS configuration.  Some options inside it can be change to provide a better experience.  The properties are presented with the following syntax:

    Cloud.Section.Name: default

which correspond to the following [JSON](http://json.org) property:

    { "Cloud": { "Section": { "Name": default } } }

* Cloud.Performance.MaxFPS: 30

  The maximum number of frames requests per second, after which the game start to be throttled down by pausing in the render thread.

* Cloud.Session.TokenTimeoutSec: 120

  The maximum number of seconds before the game stop accepting new connections.

* Cloud.Local.EncoderThreads: 2

  The number of threads dedicated to encoding the video stream.

* Cloud.Local.MaxRenderingFrames: 3

  The maximum number of queued rendering frame requested before the game start to block.

* Cloud.Local.MaxEncodingFrames: 5

  The maximum number of queued encoding frame requested before the game start to block. 


## FAQ

1. <a name="FAQ1"></a>Is MCS the same as Shinra Remote Rendering technology ?

   Shinra MCS used the same abstraction of the Direct X API to generate the rendering commands on Shinra Remote Renderer.  The implementation is however independent and simplified, and does not include many hardware acceleration and optimizations allowing Shinra Remote Renderer to scale to many clients on a single server.  It's also used a simple JPEG encoder instead of Shinra optimized encoder.

2. <a name="FAQ2"></a>My game is slower when I used Shinra MCS... will it be also the case with the Shinra Remote Renderer ?
   
   As said in [question 1](#FAQ1), Shinra MCS is an independant implementation of the Shinra Remote Renderer technology. It uses no hardware acceleration, can't share any resources from other clients and uses a software-only encoder delivering a bigger video stream.  It's also use the same resources as the client itself (it run in the same process) which can slow down your game further.  Briefly, Shinra MCS just try to imitate the Remote Rendering experience but aren't intend as a benchmark for the kind of performance you can get from Shinra Remote Rendering.
   
3. <a name="FAQ3"></a>Which port is used by MCS ?

   Shinra MCS used the following ports by default (with the <a href="#CloudProperties">CloudProperties</a> name in parenthesis) :
   
   * Video Port (`Cloud.Network.VideoPort`): 60000
   * Audio/Game Port (`Cloud.Network.GamePort`): 60001
   
   You can change which ports the ShinraMCS `-pv` and `-pg` (respectively for video and game port) options like this:
   
       ShinraClient -t localhost -pv 70000 -pg 70001

## Contacts

For more information, you can contact [fabien.ninoles@eidosmontreal.com](mailto:fabien.ninoles@eidosmontreal.com).

   